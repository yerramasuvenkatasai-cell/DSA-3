import java.util.Random;

/** Correctness test: every algorithm must agree with a trusted indexOf-based reference on all inputs. Run: java TestAll */
public class TestAll {
    static int checks = 0, failures = 0;

    static CustomArrayList reference(String t, String p) {
        CustomArrayList r = new CustomArrayList();
        if (p.isEmpty()) return r;
        int from = 0, idx;
        while ((idx = t.indexOf(p, from)) >= 0) { r.add(idx); from = idx + 1; }
        return r;
    }

    static void check(String t, String p) {
        CustomArrayList expected = reference(t, p);
        for (PatternMatcher pm : Algorithms.all()) {
            checks++;
            CustomArrayList got = pm.search(t, p);
            if (!got.sameAs(expected)) {
                failures++;
                String shown = t.length() > 60 ? t.substring(0, 60) + "..." : t;
                System.out.println("FAIL " + pm.getAlgorithmName() + " T=\"" + shown + "\" P=\"" + p + "\" expected " + expected + " got " + got);
            }
        }
    }

    public static void main(String[] args) {
        // Worked examples from the slides
        expect("ABCABCDABABCDABCDABDE", "ABCDAB", "[3, 9, 13]");
        expect("AABAAABAA", "AAB", "[0, 4]");
        expect("ABABDABACDABABCABAB", "ABABCABAB", "[10]");
        expect("HERE IS A SIMPLE EXAMPLE", "EXAMPLE", "[17]");
        expect("3141592653589793", "265", "[6]");
        expect("baabaa", "aab", "[1]");

        // Edge cases
        check("", "a"); check("a", ""); check("a", "a"); check("a", "b"); check("ab", "abc");
        check("aaaaa", "aa");            // overlapping matches
        check("a#b#a#b", "#b");          // delimiter character inside the text
        check("a#b#a#b", "a#b");         // delimiter character inside the pattern
        check("héllo wörld ünï", "ö");   // non-ASCII
        check("日本語のテキスト日本語", "日本語");
        check("￾￿ab￿", "￿"); // top of the char range

        // Randomized: small alphabets force many repeats/collisions
        Random rnd = new Random(42);
        String[] alphabets = {"ab", "ACGT", "abc#", "0123456789", "abcdefghijklmnopqrstuvwxyz "};
        for (int iter = 0; iter < 20000; iter++) {
            String a = alphabets[rnd.nextInt(alphabets.length)];
            int n = rnd.nextInt(60), m = 1 + rnd.nextInt(8);
            check(random(rnd, a, n), random(rnd, a, m));
        }
        // Patterns cut from the text (guaranteed hits)
        for (int iter = 0; iter < 5000; iter++) {
            String a = alphabets[rnd.nextInt(alphabets.length)];
            String t = random(rnd, a, 20 + rnd.nextInt(200));
            int m = 1 + rnd.nextInt(Math.min(15, t.length()));
            int s = rnd.nextInt(t.length() - m + 1);
            check(t, t.substring(s, s + m));
        }
        // Large pathological inputs
        StringBuilder as = new StringBuilder();
        for (int i = 0; i < 20000; i++) as.append('a');
        check(as.toString(), "aaaaaaaaab");
        check(as.toString(), "aaaaaaaaaa");

        System.out.println(checks + " checks, " + failures + " failures");
        if (failures > 0) System.exit(1);
        System.out.println("ALL TESTS PASSED");
    }

    static void expect(String t, String p, String positions) {
        for (PatternMatcher pm : Algorithms.all()) {
            checks++;
            String got = pm.search(t, p).toString();
            if (!got.equals(positions)) {
                failures++;
                System.out.println("FAIL (slide example) " + pm.getAlgorithmName() + " expected " + positions + " got " + got);
            }
        }
        check(t, p);
    }

    static String random(Random r, String alphabet, int len) {
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) sb.append(alphabet.charAt(r.nextInt(alphabet.length())));
        return sb.toString();
    }
}
