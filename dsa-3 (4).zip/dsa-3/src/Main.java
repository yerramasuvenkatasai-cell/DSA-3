import java.util.Scanner;

/**
 * Entry point.
 *   java Main             -> opens the Swing workbench (GUI)
 *   java Main benchmark   -> runs the 1,000-record benchmark in the console
 *   java Main console     -> interactive console test bench
 */
public class Main {

    public static void main(String[] args) throws Exception {
        String mode = args.length > 0 ? args[0].toLowerCase() : "gui";
        switch (mode) {
            case "benchmark": Benchmark.main(new String[0]); break;
            case "console": runConsole(); break;
            default: GUIApp.main(args);
        }
    }

    private static void runConsole() {
        PatternMatcher[] algos = Algorithms.all();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n==================================================");
            System.out.println("     STRING MATCHING ALGORITHM TEST BENCH");
            System.out.println("==================================================");
            System.out.println("1. Test with Custom Input (Interactive)");
            System.out.println("2. Run Benchmark Test (Synthetic Large Input)");
            System.out.println("3. Exit");
            System.out.print("Select an option (1-3): ");

            if (!scanner.hasNextLine()) break;
            String choice = scanner.nextLine().trim();

            if (choice.equals("3")) {
                System.out.println("Exiting Application. Goodbye!");
                break;
            } else if (choice.equals("1")) {
                System.out.print("\nEnter Main Text: ");
                String text = scanner.nextLine();
                System.out.print("Enter Search Pattern: ");
                String pattern = scanner.nextLine();
                if (text.isEmpty() || pattern.isEmpty()) {
                    System.out.println("Error: Text and Pattern cannot be empty.");
                    continue;
                }
                System.out.println("\n--------------------------------------------------");
                System.out.println("RESULTS FOR PATTERN: \"" + pattern + "\"");
                System.out.println("--------------------------------------------------");
                for (PatternMatcher a : algos) {
                    CustomArrayList r = a.search(text, pattern);
                    System.out.printf("%-22s -> Matches Found: %d at indices: %s%n", a.getAlgorithmName(), r.size(), r);
                }
            } else if (choice.equals("2")) {
                runSyntheticBenchmark(algos);
            } else {
                System.out.println("Invalid option. Please try again.");
            }
        }
        scanner.close();
    }

    private static void runSyntheticBenchmark(PatternMatcher[] algos) {
        int textLength = 500000;
        StringBuilder sb = new StringBuilder(textLength);
        for (int i = 0; i < textLength; i++) sb.append((char) ('A' + (i % 4)));
        String text = sb.toString();
        String pattern = "ABCDABCDAB";

        System.out.println("\n==================================================");
        System.out.println("BENCHMARK RUN (Text: 500k chars | Pattern: 10 chars)");
        System.out.println("==================================================");
        for (PatternMatcher a : algos) {
            long start = System.nanoTime();
            CustomArrayList r = a.search(text, pattern);
            System.out.printf("%-22s: %8.3f ms | Matches: %d%n", a.getAlgorithmName(), (System.nanoTime() - start) / 1e6, r.size());
        }
        System.out.println("(Full benchmark: java Main benchmark)");
    }
}
