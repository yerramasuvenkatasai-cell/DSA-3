/** Algorithm 3: Knuth-Morris-Pratt. Time O(n+m), space O(m). The text pointer never moves backward. */
public class KMPSearch implements PatternMatcher {

    @Override
    public String getAlgorithmName() {
        return "3. KMP Search";
    }

    @Override
    public CustomArrayList search(String text, String pattern) {
        CustomArrayList matches = new CustomArrayList();
        int n = text.length();
        int m = pattern.length();
        if (m == 0 || n < m) return matches;

        int[] lps = computeLPSArray(pattern);
        int i = 0, j = 0;
        while (i < n) {
            if (pattern.charAt(j) == text.charAt(i)) {
                i++;
                j++;
                if (j == m) {
                    matches.add(i - j);
                    j = lps[j - 1];
                }
            } else if (j != 0) {
                j = lps[j - 1];
            } else {
                i++;
            }
        }
        return matches;
    }

    /** lps[i] = length of the longest proper prefix of P[0..i] that is also a suffix. */
    public static int[] computeLPSArray(String pattern) {
        int m = pattern.length();
        int[] lps = new int[m];
        int len = 0;
        int i = 1;
        while (i < m) {
            if (pattern.charAt(i) == pattern.charAt(len)) {
                lps[i++] = ++len;
            } else if (len != 0) {
                len = lps[len - 1];
            } else {
                lps[i++] = 0;
            }
        }
        return lps;
    }
}
