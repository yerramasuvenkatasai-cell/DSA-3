/** One contract for every algorithm, so the GUI, benchmark and tests never depend on a specific one. */
public interface PatternMatcher {
    /** Returns every 0-based start index of pattern in text (overlapping matches included), in increasing order. */
    CustomArrayList search(String text, String pattern);

    String getAlgorithmName();
}
