/**
 * Core of the Z-Algorithm (the centrepiece of the project).
 * Z[i] = length of the longest substring starting at i that equals a prefix of S.
 * Z-box [L, R]: right-most window matched so far; R never moves left, so the build is O(|S|).
 */
public class ZAlgorithm {

    /** Picks '#' unless the pattern contains it, then the first character absent from the pattern. */
    public static char chooseDelimiter(String pattern) {
        if (pattern.indexOf('#') < 0) return '#';
        for (char c = 1; c < Character.MAX_VALUE; c++) {
            if (pattern.indexOf(c) < 0) return c;
        }
        throw new IllegalArgumentException("Pattern uses every possible character");
    }

    /** S = pattern + delimiter + text. */
    public static String combine(String text, String pattern) {
        return pattern + chooseDelimiter(pattern) + text;
    }

    /** Standard Z-array construction in O(n). Z[0] is left as 0. */
    public static int[] buildZArray(String s) {
        int n = s.length();
        int[] z = new int[n];
        int l = 0, r = 0; // Z-box [l, r)
        for (int i = 1; i < n; i++) {
            if (i < r) {
                z[i] = Math.min(r - i, z[i - l]); // reuse earlier work
            }
            while (i + z[i] < n && s.charAt(z[i]) == s.charAt(i + z[i])) {
                z[i]++;
            }
            if (i + z[i] > r) {
                l = i;
                r = i + z[i];
            }
        }
        return z;
    }

    /** All 0-based start positions of pattern in text, in O(n + m). */
    public static CustomArrayList search(String text, String pattern) {
        CustomArrayList matches = new CustomArrayList();
        int m = pattern.length();
        if (m == 0 || m > text.length()) return matches;

        int[] z = buildZArray(combine(text, pattern));
        // The delimiter is absent from the pattern, so Z[i] <= m and Z[i] == m is a full match.
        for (int i = m + 1; i < z.length; i++) {
            if (z[i] >= m) {
                matches.add(i - (m + 1));
            }
        }
        return matches;
    }
}
