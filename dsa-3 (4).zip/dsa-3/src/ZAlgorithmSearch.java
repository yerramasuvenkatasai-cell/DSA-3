/** Algorithm 2 (centrepiece): Z-Algorithm. Time O(n+m), space O(n+m). */
public class ZAlgorithmSearch implements PatternMatcher {

    @Override
    public String getAlgorithmName() {
        return "2. Z-Algorithm";
    }

    @Override
    public CustomArrayList search(String text, String pattern) {
        return ZAlgorithm.search(text, pattern);
    }
}
