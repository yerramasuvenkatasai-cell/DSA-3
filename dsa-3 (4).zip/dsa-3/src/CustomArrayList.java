/** Hand-built dynamic int array used to store match positions (no java.util collections). */
public class CustomArrayList {
    private int[] data;
    private int size;

    public CustomArrayList() {
        this.data = new int[10];
        this.size = 0;
    }

    /** Append: amortized O(1) because capacity doubles when full. */
    public void add(int element) {
        if (size == data.length) {
            resize();
        }
        data[size++] = element;
    }

    /** Indexed access: O(1). */
    public int get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        return data[index];
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int[] toArray() {
        int[] out = new int[size];
        for (int i = 0; i < size; i++) out[i] = data[i];
        return out;
    }

    /** True if both lists hold exactly the same values in the same order. */
    public boolean sameAs(CustomArrayList other) {
        if (other == null || other.size != size) return false;
        for (int i = 0; i < size; i++) {
            if (data[i] != other.data[i]) return false;
        }
        return true;
    }

    private void resize() {
        int[] newArr = new int[data.length * 2];
        for (int i = 0; i < data.length; i++) {
            newArr[i] = data[i];
        }
        data = newArr;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < size; i++) {
            if (i > 0) sb.append(", ");
            sb.append(data[i]);
        }
        return sb.append("]").toString();
    }
}
