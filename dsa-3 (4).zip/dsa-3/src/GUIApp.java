import java.awt.*;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import javax.swing.*;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;

/**
 * Swing workbench: top control panel, bottom split into (1) results & metrics with a timing bar chart
 * and (2) step-by-step process / complexity analysis. Every match is highlighted in the text.
 */
public class GUIApp extends JFrame {
    private static final Color CRIMSON = new Color(180, 40, 40);
    private static final Color TEAL = new Color(20, 120, 125);
    private static final int MAX_HIGHLIGHTS = 5000;
    private static final int MAX_LISTED = 15;

    private final PatternMatcher[] algos = Algorithms.all();

    private JTextArea textInput;
    private JTextField patternInput;
    private JComboBox<String> algorithmSelector;
    private JCheckBox ignoreCase;
    private JTextArea resultArea;
    private JTextArea processArea;
    private JLabel statusLabel;
    private BarChartPanel chart;

    public GUIApp() {
        setTitle("String Matching Application - Algorithm & Process Workbench");
        setSize(1100, 900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));

        JLabel titleLabel = new JLabel("String Matching Workbench: Z-Algorithm, Naive, KMP, Boyer-Moore, Rabin-Karp", SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        titleLabel.setOpaque(true);
        titleLabel.setBackground(CRIMSON);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(titleLabel, BorderLayout.NORTH);

        // ---- Top control panel
        JPanel top = new JPanel(new BorderLayout(6, 6));
        top.setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 12));

        textInput = new JTextArea("ABABDABACDABABCABABABCDABACDABABCABAB", 6, 70);
        textInput.setLineWrap(true);
        textInput.setWrapStyleWord(false);
        textInput.setFont(new Font("Monospaced", Font.PLAIN, 13));
        JScrollPane textScroll = new JScrollPane(textInput);
        textScroll.setBorder(BorderFactory.createTitledBorder("Target Text (matches are highlighted)"));
        top.add(textScroll, BorderLayout.CENTER);

        JPanel controls = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(3, 4, 3, 4);
        g.anchor = GridBagConstraints.WEST;

        g.gridx = 0; g.gridy = 0;
        controls.add(new JLabel("Search Pattern:"), g);
        patternInput = new JTextField("ABABCABAB", 28);
        g.gridx = 1; g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1;
        controls.add(patternInput, g);

        g.gridx = 2; g.fill = GridBagConstraints.NONE; g.weightx = 0;
        controls.add(new JLabel("Select Algorithm:"), g);
        String[] names = {
            "1. Naive Search (Brute Force O(n*m))",
            "2. Z-Algorithm (Linear O(n+m))",
            "3. KMP Search (Prefix LPS Table)",
            "4. Boyer-Moore (Bad Character Heuristic)",
            "5. Rabin-Karp (Rolling Hash)"
        };
        algorithmSelector = new JComboBox<>(names);
        algorithmSelector.setSelectedIndex(1);
        g.gridx = 3;
        controls.add(algorithmSelector, g);

        ignoreCase = new JCheckBox("Ignore case");
        g.gridx = 4;
        controls.add(ignoreCase, g);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 2));
        JButton searchBtn = new JButton("Search & Show Process");
        JButton clearBtn = new JButton("Clear");
        JButton loadFileBtn = new JButton("Load .txt file");
        JButton worstCaseBtn = new JButton("Worst-case demo");
        btnPanel.add(searchBtn);
        btnPanel.add(clearBtn);
        btnPanel.add(loadFileBtn);
        btnPanel.add(worstCaseBtn);

        JPanel controlsAndButtons = new JPanel(new BorderLayout());
        controlsAndButtons.add(controls, BorderLayout.NORTH);
        controlsAndButtons.add(btnPanel, BorderLayout.SOUTH);
        top.add(controlsAndButtons, BorderLayout.SOUTH);
        add(top, BorderLayout.CENTER);

        // ---- Bottom: results (+ chart) and process
        resultArea = monoArea(8, 40);
        JScrollPane resultScroll = new JScrollPane(resultArea);
        resultScroll.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(TEAL, 2), "1. Match Results & Performance Metrics"));
        chart = new BarChartPanel();
        chart.setBorder(BorderFactory.createTitledBorder("Execution time, all five algorithms (best of 3)"));
        chart.setPreferredSize(new Dimension(420, 150));
        JSplitPane resultSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, resultScroll, chart);
        resultSplit.setResizeWeight(0.62);

        processArea = monoArea(12, 70);
        JScrollPane processScroll = new JScrollPane(processArea);
        processScroll.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(TEAL, 2), "2. Step-by-Step Process, Mathematics & Complexity"));

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, resultSplit, processScroll);
        splitPane.setDividerLocation(235);

        statusLabel = new JLabel(" Ready.");
        statusLabel.setBorder(BorderFactory.createEmptyBorder(3, 12, 3, 12));
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setPreferredSize(new Dimension(1000, 510));
        bottom.add(splitPane, BorderLayout.CENTER);
        bottom.add(statusLabel, BorderLayout.SOUTH);
        add(bottom, BorderLayout.SOUTH);

        // ---- Actions
        searchBtn.addActionListener(e -> executeSearch());
        patternInput.addActionListener(e -> executeSearch());
        clearBtn.addActionListener(e -> clearAll());
        loadFileBtn.addActionListener(e -> loadFile());
        worstCaseBtn.addActionListener(e -> runWorstCaseDemo());
    }

    private JTextArea monoArea(int rows, int cols) {
        JTextArea a = new JTextArea(rows, cols);
        a.setEditable(false);
        a.setFont(new Font("Monospaced", Font.PLAIN, 12));
        return a;
    }

    // ------------------------------------------------------------ public hooks (also used by tests)
    public void setInputs(String text, String pattern, int algorithmIndex, boolean ignoreCaseFlag) {
        textInput.setText(text);
        patternInput.setText(pattern);
        algorithmSelector.setSelectedIndex(algorithmIndex);
        ignoreCase.setSelected(ignoreCaseFlag);
    }

    public void runWorstCaseDemo() {
        int n = 4000, m = 1000; // slide 12: n = 4,000, m = 1,000
        textInput.setText(repeat('a', n));
        patternInput.setText(repeat('a', m - 1) + "b");
        algorithmSelector.setSelectedIndex(0); // Naive first: it is the one that degrades
        ignoreCase.setSelected(false);
        executeSearch();
    }

    private void clearAll() {
        textInput.setText("");
        patternInput.setText("");
        resultArea.setText("");
        processArea.setText("");
        textInput.getHighlighter().removeAllHighlights();
        chart.setData(null, null);
        statusLabel.setText(" Cleared.");
    }

    private void loadFile() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                File file = chooser.getSelectedFile();
                String content = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
                textInput.setText(content);
                textInput.setCaretPosition(0);
                statusLabel.setText(" Loaded " + file.getName() + " (" + content.length() + " characters).");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // ------------------------------------------------------------ search
    public void executeSearch() {
        String rawText = textInput.getText();
        String rawPattern = patternInput.getText();
        if (rawText.isEmpty() || rawPattern.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Text and Pattern cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        boolean fold = ignoreCase.isSelected();
        String text = fold ? fold(rawText) : rawText;      // same length as rawText, so indices line up
        String pattern = fold ? fold(rawPattern) : rawPattern;
        int n = text.length(), m = pattern.length();

        int choice = algorithmSelector.getSelectedIndex();
        PatternMatcher selected = algos[choice];

        // Time every algorithm on identical input: best of 3 runs, and keep the result for verification.
        double[] times = new double[algos.length];
        CustomArrayList[] results = new CustomArrayList[algos.length];
        for (int a = 0; a < algos.length; a++) {
            double best = Double.MAX_VALUE;
            for (int rep = 0; rep < 3; rep++) {
                long t0 = System.nanoTime();
                results[a] = algos[a].search(text, pattern);
                best = Math.min(best, (System.nanoTime() - t0) / 1e6);
            }
            times[a] = best;
        }
        CustomArrayList matches = results[choice];
        boolean agree = true;
        for (CustomArrayList r : results) agree &= r.sameAs(results[0]);

        highlight(matches, m);

        // ---- Pane 1
        StringBuilder res = new StringBuilder();
        res.append(String.format("Selected Algorithm : %s%n", selected.getAlgorithmName()));
        res.append(String.format("Text Length (n=%,d) | Pattern Length (m=%,d)%s%n", n, m, fold ? " | case-insensitive" : ""));
        res.append(String.format("Execution Time     : %.4f ms%n", times[choice]));
        res.append(String.format("Total Matches Found: %,d%n", matches.size()));
        res.append("Match Positions    : ");
        if (matches.size() == 0) {
            res.append("None found.");
        } else {
            int limit = Math.min(matches.size(), MAX_LISTED);
            for (int i = 0; i < limit; i++) {
                int pos = matches.get(i);
                int[] lc = getLineAndCol(rawText, pos);
                res.append(String.format("[%d (L:%d, C:%d)] ", pos, lc[0], lc[1]));
            }
            if (matches.size() > limit) res.append("... (and ").append(matches.size() - limit).append(" more)");
        }
        res.append("\n\nAll algorithms (ms):\n");
        for (int a = 0; a < algos.length; a++) {
            res.append(String.format("  %-22s %9.4f  (%d matches)%n", algos[a].getAlgorithmName(), times[a], results[a].size()));
        }
        resultArea.setText(res.toString());
        resultArea.setCaretPosition(0);

        String[] labels = new String[algos.length];
        for (int a = 0; a < algos.length; a++) labels[a] = shortName(algos[a]);
        chart.setData(labels, times);

        statusLabel.setText(agree
                ? " Verified: all five algorithms returned identical match positions."
                : " WARNING: algorithms disagree, check the implementation!");
        statusLabel.setForeground(agree ? new Color(20, 110, 40) : Color.RED);

        processArea.setText(buildProcessText(choice, text, pattern, matches));
        processArea.setCaretPosition(0);
    }

    private String buildProcessText(int choice, String text, String pattern, CustomArrayList matches) {
        int n = text.length(), m = pattern.length();
        StringBuilder p = new StringBuilder();
        p.append(String.format("=== MATHEMATICAL CALCULATION & COMPLEXITY ANALYSIS (n=%,d, m=%,d) ===%n", n, m));
        p.append("------------------------------------------------------------------------------------\n");
        String shown = matches.size() > 30 ? "(" + matches.size() + " positions, see pane 1)" : matches.toString();

        switch (choice) {
            case 0:
                p.append("• Core concept   : slide the pattern over the text one index at a time, compare left to right.\n");
                p.append("• Best case      : O(n)    [first character mismatches at every window]\n");
                p.append("• Worst case     : O(n*m)  [repetitive input: almost m comparisons at every shift]\n");
                p.append("• Space          : O(1)\n");
                p.append("• Step 1 (Shifts): s ranges from 0 to n - m = ").append(n - m).append("\n");
                p.append(String.format("• Step 2 (Bound) : at most (n-m+1)*m = %,d character comparisons%n", (long) (n - m + 1) * m));
                p.append("• Step 3 (Result): ").append(shown).append("\n");
                break;
            case 1: {
                String combined = ZAlgorithm.combine(text, pattern);
                char delim = ZAlgorithm.chooseDelimiter(pattern);
                int[] z = ZAlgorithm.buildZArray(combined);
                p.append("• Core concept   : Z[i] = longest substring starting at i that equals a prefix of S = P + '" + printable(delim) + "' + T.\n");
                p.append("• Best case      : O(n + m)\n");
                p.append("• Worst case     : O(n + m)  [Z-box [L, R]: R never moves left]\n");
                p.append("• Space          : O(n + m)\n");
                p.append("• Step 1 (Concatenation): |S| = ").append(combined.length()).append("\n");
                if (combined.length() <= 40) p.append("                         S = ").append(spaced(combined)).append("\n");
                p.append("• Step 2 (Z-array)      : Z = ").append(arrayPreview(z, 40)).append("\n");
                p.append("• Step 3 (Extraction)   : Z[i] = m = ").append(m).append(" means a match at text index i - m - 1.  Matches: ").append(shown).append("\n");
                break;
            }
            case 2: {
                int[] lps = KMPSearch.computeLPSArray(pattern);
                p.append("• Core concept   : LPS table lets the pattern slide forward without moving the text pointer back.\n");
                p.append("• Best case      : O(n + m)\n");
                p.append("• Worst case     : O(n + m)  [each decrease of j is paid by an earlier increase]\n");
                p.append("• Space          : O(m)\n");
                p.append("• Step 1 (LPS)   : lps[i] = longest proper prefix of P[0..i] that is also a suffix\n");
                if (m <= 40) p.append("                    P   = ").append(spaced(pattern)).append("\n");
                p.append("                    LPS = ").append(arrayPreview(lps, 40)).append("\n");
                p.append("• Step 2 (Shift) : on mismatch at j, set j = LPS[j-1]; the text index i never decreases.\n");
                p.append("• Step 3 (Result): ").append(shown).append("\n");
                break;
            }
            case 3: {
                int[] last = BoyerMooreSearch.buildLastTable(pattern);
                p.append("• Core concept   : compare right-to-left; the bad-character rule can skip up to m text characters.\n");
                p.append("• Best case      : O(n / m)  [text chars absent from P give a full jump of m]\n");
                p.append("• Worst case     : O(n * m)  [bad-character rule alone can shift by just 1 on repetitive input]\n");
                p.append("• Space          : O(sigma) table\n");
                p.append("• Step 1 (Table) : last[c] = rightmost index of c in P (-1 if absent):\n                    ");
                StringBuilder seen = new StringBuilder();
                int shownChars = 0;
                for (int i = 0; i < m && shownChars < 20; i++) {
                    char c = pattern.charAt(i);
                    if (pattern.indexOf(c) == i) { seen.append(printable(c)).append(':').append(BoyerMooreSearch.lastOf(last, c)).append("  "); shownChars++; }
                }
                p.append(seen).append("\n");
                p.append("• Step 2 (Shift) : shift = max(1, j - last[c]) for mismatch at pattern index j with text char c.\n");
                p.append("• Step 3 (Result): ").append(shown).append("\n");
                break;
            }
            default: {
                long h = 1;
                for (int i = 0; i < m - 1; i++) h = (h * RabinKarpSearch.BASE) % RabinKarpSearch.MOD;
                long ph = 0;
                for (int i = 0; i < m; i++) ph = (RabinKarpSearch.BASE * ph + pattern.charAt(i)) % RabinKarpSearch.MOD;
                p.append("• Core concept   : hash every window with a rolling polynomial hash; verify only when hashes are equal.\n");
                p.append("• Best case      : O(n + m)  [expected]\n");
                p.append("• Worst case     : O(n * m)  [many spurious hash hits]\n");
                p.append("• Space          : O(1)\n");
                p.append("• Step 1 (Hash)  : base d = ").append(RabinKarpSearch.BASE).append(", q = ").append(RabinKarpSearch.MOD)
                        .append(", H = d^(m-1) mod q = ").append(h).append(", h(P) = ").append(ph).append("\n");
                p.append("• Step 2 (Roll)  : h_new = (d * (h_old - T[i]*H) + T[i+m]) mod q\n");
                p.append("• Step 3 (Verify): equal hashes trigger a character-by-character check (collisions are possible).\n");
                p.append("• Step 4 (Result): ").append(shown).append("\n");
            }
        }
        return p.toString();
    }

    // ------------------------------------------------------------ helpers
    private void highlight(CustomArrayList matches, int m) {
        Highlighter hl = textInput.getHighlighter();
        hl.removeAllHighlights();
        Highlighter.HighlightPainter painter = new DefaultHighlighter.DefaultHighlightPainter(new Color(255, 190, 70));
        int limit = Math.min(matches.size(), MAX_HIGHLIGHTS);
        try {
            for (int i = 0; i < limit; i++) hl.addHighlight(matches.get(i), matches.get(i) + m, painter);
        } catch (javax.swing.text.BadLocationException ignored) { }
        if (matches.size() > 0) textInput.setCaretPosition(matches.get(0));
    }

    /** Per-character lower-casing, so the string length (and therefore every index) is preserved. */
    private static String fold(String s) {
        char[] c = s.toCharArray();
        for (int i = 0; i < c.length; i++) c[i] = Character.toLowerCase(c[i]);
        return new String(c);
    }

    private static String shortName(PatternMatcher p) {
        String n = p.getAlgorithmName();
        return n.substring(3).replace(" Search", "").replace("-Algorithm", "");
    }

    private static String printable(char c) {
        return c < 32 ? String.format("\\u%04x", (int) c) : String.valueOf(c);
    }

    private static String spaced(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) sb.append(printable(s.charAt(i))).append(' ');
        return sb.toString().trim();
    }

    private static String repeat(char ch, int n) {
        char[] c = new char[n];
        java.util.Arrays.fill(c, ch);
        return new String(c);
    }

    private static String arrayPreview(int[] arr, int limit) {
        StringBuilder sb = new StringBuilder("[");
        int len = Math.min(arr.length, limit);
        for (int i = 0; i < len; i++) sb.append(arr[i]).append(i < len - 1 ? ", " : "");
        if (arr.length > limit) sb.append(", ...");
        return sb.append("]").toString();
    }

    private static int[] getLineAndCol(String text, int index) {
        int line = 1, col = 1;
        for (int i = 0; i < index && i < text.length(); i++) {
            if (text.charAt(i) == '\n') { line++; col = 1; } else { col++; }
        }
        return new int[]{line, col};
    }

    /** Minimal bar chart; the largest bar is scaled to the panel height. */
    private static class BarChartPanel extends JPanel {
        private String[] labels;
        private double[] values;

        void setData(String[] labels, double[] values) {
            this.labels = labels;
            this.values = values;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            if (values == null) return;
            Graphics2D g = (Graphics2D) g0;
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Insets in = getInsets();
            int w = getWidth() - in.left - in.right, h = getHeight() - in.top - in.bottom;
            double max = 0;
            for (double v : values) max = Math.max(max, v);
            if (max <= 0) max = 1;
            int slot = w / values.length, barW = Math.max(12, slot - 20);
            int baseY = in.top + h - 20, maxBar = h - 44;
            FontMetrics fm = g.getFontMetrics();
            for (int i = 0; i < values.length; i++) {
                int bh = (int) Math.max(2, Math.round(values[i] / max * maxBar));
                int x = in.left + i * slot + (slot - barW) / 2;
                g.setColor(i == 1 ? CRIMSON : TEAL); // Z-Algorithm is the centrepiece
                g.fillRect(x, baseY - bh, barW, bh);
                g.setColor(Color.DARK_GRAY);
                String v = String.format("%.3f", values[i]);
                g.drawString(v, x + (barW - fm.stringWidth(v)) / 2, baseY - bh - 4);
                g.drawString(labels[i], x + (barW - fm.stringWidth(labels[i])) / 2, baseY + 14);
            }
            g.setColor(Color.GRAY);
            g.drawLine(in.left, baseY, in.left + w, baseY);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GUIApp().setVisible(true));
    }
}
