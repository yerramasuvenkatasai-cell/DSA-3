/** Registry of the five matchers in the order shown in the GUI dropdown and the slides. */
public final class Algorithms {
    private Algorithms() {}

    public static PatternMatcher[] all() {
        return new PatternMatcher[] {
            new NaiveSearch(), new ZAlgorithmSearch(), new KMPSearch(),
            new BoyerMooreSearch(), new RabinKarpSearch()
        };
    }
}
