/** Algorithm 1: Naive (brute force). Best O(n), worst O(n*m), space O(1). */
public class NaiveSearch implements PatternMatcher {

    @Override
    public String getAlgorithmName() {
        return "1. Naive Search";
    }

    @Override
    public CustomArrayList search(String text, String pattern) {
        CustomArrayList matches = new CustomArrayList();
        int n = text.length();
        int m = pattern.length();
        if (m == 0 || n < m) return matches;

        for (int i = 0; i <= n - m; i++) {
            int j = 0;
            while (j < m && text.charAt(i + j) == pattern.charAt(j)) {
                j++;
            }
            if (j == m) matches.add(i);
        }
        return matches;
    }
}
