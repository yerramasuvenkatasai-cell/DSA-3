/** Algorithm 5: Rabin-Karp rolling hash (q = 101). Expected O(n+m), worst O(n*m), space O(1). */
public class RabinKarpSearch implements PatternMatcher {
    public static final long BASE = 256;
    public static final long MOD = 101;

    @Override
    public String getAlgorithmName() {
        return "5. Rabin-Karp Search";
    }

    @Override
    public CustomArrayList search(String text, String pattern) {
        CustomArrayList matches = new CustomArrayList();
        int m = pattern.length();
        int n = text.length();
        if (m == 0 || n < m) return matches;

        long p = 0; // hash of pattern
        long t = 0; // hash of current window
        long h = 1; // BASE^(m-1) mod MOD

        for (int i = 0; i < m - 1; i++) h = (h * BASE) % MOD;
        for (int i = 0; i < m; i++) {
            p = (BASE * p + pattern.charAt(i)) % MOD;
            t = (BASE * t + text.charAt(i)) % MOD;
        }

        for (int i = 0; i <= n - m; i++) {
            if (p == t) { // verify: equal hashes can be collisions
                int j = 0;
                while (j < m && text.charAt(i + j) == pattern.charAt(j)) j++;
                if (j == m) matches.add(i);
            }
            if (i < n - m) {
                t = (BASE * (t - text.charAt(i) * h % MOD + MOD) + text.charAt(i + m)) % MOD;
            }
        }
        return matches;
    }
}
