import java.io.PrintWriter;
import java.util.Random;

/**
 * Console benchmark:  java Main benchmark
 *   Test 1: 1,000 generated DNA records (400 small / 400 medium / 200 large); all five algorithms are
 *           checked against the Naive result and timed.
 *   Test 2: worst-case family for Naive (text = a^n, pattern = a^(m-1) b, m = n/20).
 *   Test 3: the slide-12 demo (n = 4,000, m = 1,000), median of 25 runs after warm-up.
 * Results are also written to benchmark_results.csv.
 */
public class Benchmark {
    static final PatternMatcher[] ALGOS = Algorithms.all();

    public static void main(String[] args) throws Exception {
        PrintWriter csv = new PrintWriter("benchmark_results.csv");
        csv.println("test,group,records_or_n,pattern_len,avg_text_len,algorithm,avg_ms,outputs_identical");

        warmUp();
        test1(csv);
        test2(csv);
        test3(csv);

        csv.close();
        System.out.println("\nCSV written to benchmark_results.csv");
    }

    // ---------------------------------------------------------------- Test 1
    static void test1(PrintWriter csv) {
        System.out.println("==================================================================");
        System.out.println("TEST 1: 1,000 generated DNA records (seed 2025)");
        System.out.println("==================================================================");
        Random rnd = new Random(2025);
        String[] names = {"Small", "Medium", "Large"};
        int[] counts = {400, 400, 200};
        int[] lo = {100, 10_000, 200_000};
        int[] hi = {1_000, 100_000, 500_000};

        boolean allIdentical = true;
        int record = 0;
        for (int g = 0; g < 3; g++) {
            double[] totalMs = new double[ALGOS.length];
            long totalLen = 0;
            boolean identical = true;
            for (int r = 0; r < counts[g]; r++, record++) {
                int n = lo[g] + rnd.nextInt(hi[g] - lo[g] + 1);
                String text = dna(rnd, n);
                int m = 5 + rnd.nextInt(16);
                // Half the patterns are cut from the text (match guaranteed), half are random.
                String pattern = (record % 2 == 0) ? cut(text, m, rnd) : dna(rnd, m);
                totalLen += n;
                CustomArrayList reference = null;
                for (int a = 0; a < ALGOS.length; a++) {
                    long t0 = System.nanoTime();
                    CustomArrayList res = ALGOS[a].search(text, pattern);
                    totalMs[a] += (System.nanoTime() - t0) / 1e6;
                    if (reference == null) reference = res;
                    else if (!reference.sameAs(res)) identical = false;
                }
            }
            allIdentical &= identical;
            System.out.printf("%-6s %4d records, avg text length %,9d, outputs identical: %s%n",
                    names[g], counts[g], totalLen / counts[g], identical ? "Yes" : "NO");
            for (int a = 0; a < ALGOS.length; a++) {
                double avg = totalMs[a] / counts[g];
                System.out.printf("    %-22s %9.4f ms%n", ALGOS[a].getAlgorithmName(), avg);
                csv.printf("generated,%s,%d,,%d,%s,%.4f,%s%n", names[g], counts[g], totalLen / counts[g],
                        ALGOS[a].getAlgorithmName(), avg, identical);
            }
        }
        System.out.println(allIdentical ? "-> All five algorithms agreed on all 1,000 records." : "-> MISMATCH FOUND");
    }

    // ---------------------------------------------------------------- Test 2
    static void test2(PrintWriter csv) {
        System.out.println("\n==================================================================");
        System.out.println("TEST 2: worst case for Naive  (text a^n, pattern a^(m-1)b, m = n/20)");
        System.out.println("==================================================================");
        System.out.printf("%9s %7s", "n", "m");
        for (PatternMatcher p : ALGOS) System.out.printf(" %12s", p.getAlgorithmName().substring(3).split(" ")[0]);
        System.out.println("   Naive/Z speed-up");
        for (int n = 20_000; n <= 160_000; n *= 2) {
            int m = n / 20;
            String text = repeat('a', n);
            String pattern = repeat('a', m - 1) + "b";
            System.out.printf("%,9d %,7d", n, m);
            double naiveMs = 0, zMs = 0;
            CustomArrayList reference = null;
            boolean identical = true;
            for (int a = 0; a < ALGOS.length; a++) {
                long t0 = System.nanoTime();
                CustomArrayList res = ALGOS[a].search(text, pattern);
                double ms = (System.nanoTime() - t0) / 1e6;
                if (reference == null) reference = res; else identical &= reference.sameAs(res);
                if (a == 0) naiveMs = ms;
                if (a == 1) zMs = ms;
                System.out.printf(" %9.3f ms", ms);
                csv.printf("worst_case,n=%d,%d,%d,%d,%s,%.4f,%s%n", n, n, m, n, ALGOS[a].getAlgorithmName(), ms, identical);
            }
            System.out.printf("   %.0fx%n", naiveMs / zMs);
        }
    }

    // ---------------------------------------------------------------- Test 3
    static void test3(PrintWriter csv) {
        int n = 4000, m = 1000, runs = 25;
        System.out.println("\n==================================================================");
        System.out.println("TEST 3: slide-12 demo, n = 4,000, m = 1,000 (median of " + runs + " runs after warm-up)");
        System.out.println("==================================================================");
        String text = repeat('a', n);
        String pattern = repeat('a', m - 1) + "b";
        long naiveOps = (long) (n - m + 1) * m;
        System.out.printf("Naive bound (n-m+1)*m = %,d comparisons; linear bound n+m = %,d steps%n", naiveOps, n + m);
        for (int w = 0; w < 200; w++) for (PatternMatcher p : ALGOS) p.search(text, pattern);
        for (PatternMatcher p : ALGOS) {
            double[] t = new double[runs];
            for (int r = 0; r < runs; r++) {
                long t0 = System.nanoTime();
                p.search(text, pattern);
                t[r] = (System.nanoTime() - t0) / 1e6;
            }
            java.util.Arrays.sort(t);
            double median = t[runs / 2];
            System.out.printf("    %-22s %9.4f ms%n", p.getAlgorithmName(), median);
            csv.printf("slide12_demo,n=4000,%d,%d,%d,%s,%.4f,true%n", n, m, n, p.getAlgorithmName(), median);
        }
    }

    // ---------------------------------------------------------------- helpers
    static void warmUp() {
        Random rnd = new Random(1);
        for (int i = 0; i < 300; i++) {
            String t = dna(rnd, 5000), p = dna(rnd, 8);
            for (PatternMatcher pm : ALGOS) pm.search(t, p);
        }
    }

    static String cut(String text, int m, Random rnd) {
        int s = rnd.nextInt(text.length() - m);
        return text.substring(s, s + m);
    }

    static String dna(Random rnd, int len) {
        char[] c = new char[len];
        for (int i = 0; i < len; i++) c[i] = "ACGT".charAt(rnd.nextInt(4));
        return new String(c);
    }

    static String repeat(char ch, int n) {
        char[] c = new char[n];
        java.util.Arrays.fill(c, ch);
        return new String(c);
    }
}
