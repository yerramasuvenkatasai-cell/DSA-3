/** Algorithm 4: Boyer-Moore with the bad-character rule only. Best O(n/m), worst O(n*m), space O(sigma). */
public class BoyerMooreSearch implements PatternMatcher {

    @Override
    public String getAlgorithmName() {
        return "4. Boyer-Moore Search";
    }

    @Override
    public CustomArrayList search(String text, String pattern) {
        CustomArrayList matches = new CustomArrayList();
        int m = pattern.length();
        int n = text.length();
        if (m == 0 || n < m) return matches;

        int[] last = buildLastTable(pattern);

        int s = 0;
        while (s <= n - m) {
            int j = m - 1;
            while (j >= 0 && pattern.charAt(j) == text.charAt(s + j)) j--;
            if (j < 0) {
                matches.add(s);
                s += (s + m < n) ? Math.max(1, m - lastOf(last, text.charAt(s + m))) : 1;
            } else {
                s += Math.max(1, j - lastOf(last, text.charAt(s + j)));
            }
        }
        return matches;
    }

    /**
     * last[c] = rightmost index of c in the pattern, -1 if absent. The table only spans characters up to the
     * largest one in the pattern (small for ASCII, correct for any Unicode); larger text characters are absent.
     */
    public static int[] buildLastTable(String pattern) {
        int max = 0;
        for (int i = 0; i < pattern.length(); i++) max = Math.max(max, pattern.charAt(i));
        int[] last = new int[max + 1];
        for (int i = 0; i < last.length; i++) last[i] = -1;
        for (int i = 0; i < pattern.length(); i++) last[pattern.charAt(i)] = i;
        return last;
    }

    /** Safe lookup: characters beyond the table are not in the pattern. */
    public static int lastOf(int[] last, char c) {
        return c < last.length ? last[c] : -1;
    }
}
