# String Matching Workbench (25CS2103E, Team 03)

Naive, Z-Algorithm, KMP, Boyer-Moore (bad character) and Rabin-Karp, built from scratch in Java with a Swing GUI,
a 1,000-record benchmark and a correctness test. Needs JDK 11+; no external libraries.

## Build and run
    cd src
    mkdir -p ../out && javac -d ../out *.java
    java -cp ../out Main              # Swing workbench
    java -cp ../out Main benchmark    # 1,000 records + worst cases, writes benchmark_results.csv
    java -cp ../out Main console      # interactive console bench
    java -cp ../out TestAll           # 125,125 correctness checks against an indexOf reference

## Files (src/)
| File | Purpose |
|---|---|
| PatternMatcher.java | Interface: one contract for all five algorithms |
| CustomArrayList.java | Hand-built dynamic int array that stores match positions |
| NaiveSearch / ZAlgorithmSearch / KMPSearch / BoyerMooreSearch / RabinKarpSearch | The five algorithms |
| ZAlgorithm.java | Z-array construction and search (used by ZAlgorithmSearch) |
| Algorithms.java | Registry of the five matchers, in dropdown order |
| GUIApp.java | Control panel, highlighted text, results pane, bar chart, process pane |
| Benchmark.java | 1,000 DNA records, worst-case family, slide-12 demo, CSV output |
| TestAll.java | Randomized and edge-case correctness test |
| Main.java | Entry point (gui / benchmark / console) |
